
# IMPORTANT!!!!
# -> Start R by double-clicking the file "make_it_pama-ready.R" or use setwd()



# Content
  # 1. Install / Load pama
  # 2. Make project reproducible
  # 3. Reproducing your project



# 1. Install / Load pama ####

  # 1.1 "pama" installieren, falls nicht schon vorhanden
    if(!require(pama)) {
      if(!require("devtools")) install.packages("devtools")
      library(devtools)

      #devtools::install_github("https://github.com/SimonRess/pama") # <- "main" = newest updates, is always in development (could therefore sometimes contain bugs!)
      devtools::install_github("https://github.com/SimonRess/pama/tree/v0.1.2", build_vignettes = TRUE) # <- use stable version


      # or local installation:
        # install.packages("...\pama_0.1.2.tar.gz", repo = NULL, type="source")
    }

  # 1.2 Load pama
    library(pama)

  # 1.3 Check functions documentation and vignette (-> "User guides, package vignettes and other documentation" -> "pama")
    help(package = "pama") # <- Package documentation


# ---------------------------------------------------------------------- #
# ---------------------------------------------------------------------- #


# 2. Make project reproducible ####

## 2.1 Creating a "requirements" file: `create_requirements()` ####
  # In order to make your project reproducible a central location where all the information of the packages and
  # their versions utilized in the project is very helpful. Using `create_requirements()` a "requirements"-file
  # will be created that contains all necessary information (incl. R version, package name & version structured
  # according to your scripts) to A.) replicate your library-folder with the exact same package versions
  # (-> `install_requirements()`) and/or B.) switch the utilized versions of your packages (-> `apply_library_version()`).

  #Creating a req-file in "getwd() called "requirements_<date>.txt", with list structure
    create_reqirements_file(draft = FALSE, script.paths = "./Scripts", lib.path = "./lib")

## 2.2 Adjust package-loading in R scripts to pama-style: `apply_library_version()` ####
  # In order to ensure that always the correct versions of the packages used are loaded in the future,
  # they must be specified in the code. `apply_library_version()` replaces all functions defined in `<patterns>`
  # (default: `library()` and `require()`) by the pama-function
  # `library_version(<package_name>, <package_version>)`. The `<package_name>` attribute is extracted from the
  # scripts. The `<package_version>` is read from the specified requirements-file.

  #Adjust package-loading within R scripts in .\Scripts to pama-style, using versions from the "requirements.txt"-file
    apply_library_version(req.file.name = paste0("requirements_",Sys.Date(), ".txt"),
                          script.paths = "./Scripts/")


# ---------------------------------------------------------------------- #
# ---------------------------------------------------------------------- #


## 3. Reproducing your project ####

### 3.1 Setup a project library: `setupLibrary()`
  # In the new project directory a library folder with the standard packages of the desired R version
  # can be created with `setupLibrary()`.

  #Creating a "lib"-folder with all standard packages of the specified R Version (-> here specified by R.home())
    setupLibrary(new.lib = "lib_versions", main.lib.path = paste0(R.home(), "/library"))


### 3.2 Installing requires packages: `install_requirements()`
  # After that, all packages with the used versions from the "requirements" files can be installed
  # into the new library folder using `install_requirements()`.

  #Install all package versions specified in "requirements_<date>.txt"-file in the WD
    install_requirements(library.folder.name = "lib_versions", req.file.name = paste0("requirements_",Sys.Date(), ".txt"))


# ---------------------------------------------------------------------- #
# ---------------------------------------------------------------------- #


## 4. Work on your project
  # !!! ALWAYS, AT FIRST, BEFORE WORKING IN YOUR PROJECT !!!: 4.1 `modify_libPaths(reset=...)` function -> Tell your R-Session in which folder to search for package-versions
    # 4.1.1 .libPaths() -> Check ob wirklich nur noch der angegebene Ordner (oben) für Suche nach Libraries genutzt wird
    # 4.1.2 library()$results[,1] -> see all (pama-comform) installed libraries
  # 4.2 `install_package_version()` function -> install new packages by version
  # 4.3 `library_version()` function -> load single package by version
  # 4.4 `load_requirements()` function -> load packages from the requirements file
  # 4.5 `citations2()` function -> cite your packages



