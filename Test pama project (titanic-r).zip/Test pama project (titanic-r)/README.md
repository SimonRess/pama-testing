# Exploring the Titanic Dataset with R

Scripts to explore the Titanic Dataset, with R. The goal is to do machine learning to predict whether a passenger will die or live, considering his data: is the passenger travelling in third class? Where did he embark? Is this passenger adult? Is the passenger a woman or a man? Etc.

# Tutorials followed
I followed the excellent tutorials, which can be seen at the following addresses:
- https://www.kaggle.com/mrisdal/titanic/exploring-survival-on-the-titanic
- https://github.com/wehrley/wehrley.github.io/blob/master/SOUPTONUTS.md

